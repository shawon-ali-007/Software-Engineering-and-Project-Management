# Shawon Ali – Math Whiz

A Java Servlet/JSP mathematical quiz application using JDBC and MySQL.

## Technology
- Java 21, Jakarta Servlet 6, JSP
- Apache Tomcat 10.1+
- Maven
- MySQL 8+

## Setup
1. Create the database using `database/math_whiz_db.sql` in MySQL Workbench.
2. Open `src/main/java/com/shawon/mathwhiz/dao/DBConnection.java` and set your MySQL username/password.
3. Open this folder in IntelliJ IDEA as a Maven project.
4. Configure Tomcat 10.1+ as the application server.
5. Run `mvn clean package`.
6. Deploy `target/MathWhiz.war` to Tomcat, or run the project using the IntelliJ Tomcat configuration.
7. Visit `http://localhost:8080/MathWhiz/`.

## Scoring
| Question | Base marks | Difficulty | Multiplier | Maximum |
|---|---:|---|---:|---:|
| Prime | 2 | EASY | 1 | 2 |
| Modulus | 2 | NORMAL | 2 | 4 |
| Trigonometry | 3 | HARD | 3 | 9 |
| Trigonometry | 3 | NORMAL | 2 | 6 |
| **Total** | **10** | | | **21** |

Final marks = Base marks × difficulty multiplier. Wrong answer = 0.

## Project structure
- `MathService.java`: mathematical functions and answer checking
- `GameServlet.java`: game flow and score calculation
- `ScoreDAO.java`: JDBC insert and leaderboard query
- JSP pages: welcome, game, result, leaderboard
- `database/math_whiz_db.sql`: database schema

## Notes
- Trigonometric input is in degrees.
- Decimal answers are checked with a tolerance.
- Tangent is rejected where it is undefined.
- Update database credentials before running.
